package fr.metro.items.weapons;

//Definition of a new weapon
public class Riffle extends Weapon {
    public Riffle(){
        super("It's a riffle, point and shoot", 10);
    }
}
