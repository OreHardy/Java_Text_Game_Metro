package fr.metro.items.weapons;

//Definition of a new weapon, fists are used by default
public class Fist extends Weapon{
    public Fist() {
        super("UPPERCUT !!", 4);
    }


}
