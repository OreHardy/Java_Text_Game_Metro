package fr.metro.items.weapons;

//Definition of a new weapon
public class Knife extends Weapon {
    public Knife(){
        super("It's a knife, maybe useful to cut butter.",5);
    }
}
