package fr.metro.items.weapons;

//Definition of a new weapon
public class Pistol extends Weapon {
    public Pistol(){
        super("It's an old Red Line pistol  .", 8);
    }
}
