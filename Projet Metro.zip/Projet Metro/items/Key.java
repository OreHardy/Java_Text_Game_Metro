package fr.metro.items;

//Definition of our Key class
public class Key extends Item {
    public Key() {
        super("unlock a door", ItemType.SPECIAL);
    }
}
