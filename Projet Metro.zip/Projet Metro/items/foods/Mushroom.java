package fr.metro.items.foods;

//Definition of a new food item
public class Mushroom extends Food{
    public Mushroom(){
        super("A little white mushroom.", 2);
    }
}
