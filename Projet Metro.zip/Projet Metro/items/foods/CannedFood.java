package fr.metro.items.foods;

//Definition of a new food item
public class CannedFood extends Food{
    public CannedFood(){
        super("It's a little rusty, but the food should be fine", 10);
    }
}
