package fr.metro.items.armors;

//Definition of a piece of armor
public class BasicChestplate extends Armor{
    public BasicChestplate(){
        super("Rusty steal plate, its usefulness is questionable...",ItemType.ARMOR_TORSO);
    }
}
