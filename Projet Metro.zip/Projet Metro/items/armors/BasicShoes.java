package fr.metro.items.armors;

//Definition of a piece of armor
public class BasicShoes extends Armor{
    public BasicShoes(){
        super("A pair of old sneakers, it reminds you of simpler times",ItemType.ARMOR_FEET);
    }
}
