package fr.metro.items.armors;

//Definition of a piece of armor
public class BasicLegPiece extends Armor{
    public BasicLegPiece(){
        super("An old jean fixed with tape",ItemType.ARMOR_LEG);
    }
}
